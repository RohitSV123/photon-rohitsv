package com.photon.interview.rohitsv.product_service.controller;

import com.photon.interview.rohitsv.product_service.model.dto.ProductDto;
import com.photon.interview.rohitsv.product_service.service.ProductService;
import jakarta.websocket.server.PathParam;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductContoller {

    private final ProductService productService;

    public ProductContoller(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping(path="/")
    public List<ProductDto> getProducts() {
        return productService.getAllProducts();
    }

    @GetMapping(path = "")
    public ProductDto getProduct(@RequestParam(name="id") String id) {
        return productService.getProductById(id);
    }

    @PostMapping(path="")
    public ProductDto createProduct(@RequestBody @Validated ProductDto productDto) {
        return productService.createProduct(productDto);
    }

}
