package com.photon.interview.rohitsv.product_service.exception;

public class InvalidProductError extends RuntimeException {

    public InvalidProductError(String message) {
        super(message);
    }
}
