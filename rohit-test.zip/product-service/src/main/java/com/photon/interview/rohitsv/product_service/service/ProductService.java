package com.photon.interview.rohitsv.product_service.service;

import com.photon.interview.rohitsv.product_service.exception.InvalidProductError;
import com.photon.interview.rohitsv.product_service.model.dto.ProductDto;
import com.photon.interview.rohitsv.product_service.model.entity.Product;
import com.photon.interview.rohitsv.product_service.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class  ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<ProductDto> getAllProducts() {
        return productRepository.findAll()
                                .stream()
                                .map(this::transform)
                                .collect(Collectors.toList());
    }

    public ProductDto createProduct(ProductDto productDto) throws InvalidProductError {
        Product product = this.transform(productDto);
        return this.transform(productRepository.save(product));
    }


    public ProductDto getProductById(String idString) {

        long id = parseId(idString);
        if(id == -1) throw new InvalidProductError("Invalid product ID");
        return productRepository.findById(id)
                                .map(this::transform)
                                .orElseThrow(()->new InvalidProductError("Invalid product requested"));
    }

    private long parseId(String id) {
        try {
            return Long.parseLong(id);
        } catch(NumberFormatException ex) {
            return -1;
        }
    }

    private ProductDto transform(Product product) {
        return ProductDto.builder()
                         .id(product.getId())
                         .name(product.getName())
                         .description(product.getDescription())
                         .price(product.getPrice())
                         .imageUrl(product.getImageUrl())
                         .build();
    }

    private Product transform(ProductDto productDto) {
        return Product.builder()
                .id(productDto.getId())
                .name(productDto.getName())
                .description(productDto.getDescription())
                .price(productDto.getPrice())
                .imageUrl(productDto.getImageUrl())
                .build();
    }

}
