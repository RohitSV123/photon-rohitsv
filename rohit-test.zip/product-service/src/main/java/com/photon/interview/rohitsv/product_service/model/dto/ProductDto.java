package com.photon.interview.rohitsv.product_service.model.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductDto {
    private long id;
    private String name;
    private String description;
    private double price;
    private String imageUrl;
}
