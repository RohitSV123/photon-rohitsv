CREATE TABLE Product (
    id          INTEGER PRIMARY KEY,
    name        VARCHAR(20),
    description VARCHAR(64),
    price       INTEGER,
    image_url   VARCHAR(40)
);