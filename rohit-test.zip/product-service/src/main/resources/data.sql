

insert into Product
(id, name, description, price, image_url)
values
(1, 'iphone15', 'iphone red color', 62500.50, 'https://apple.com/iphone15');