package com.photon.interview.rohitsv.order_service.model.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderDto {
    private Long id;
    private String customerName;
    private Long productId;
    private String orderDate;
}
