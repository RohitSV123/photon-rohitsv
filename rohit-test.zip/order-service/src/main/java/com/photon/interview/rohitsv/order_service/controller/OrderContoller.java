package com.photon.interview.rohitsv.order_service.controller;

import com.photon.interview.rohitsv.order_service.exception.InvalidProductError;
import com.photon.interview.rohitsv.order_service.model.dto.OrderDto;
import com.photon.interview.rohitsv.order_service.service.OrderService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderContoller {

    private final OrderService orderService;

    public OrderContoller(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping(path="")
    public OrderDto createOrder(@RequestBody @Validated OrderDto orderDto) throws InvalidProductError {
        return orderService.createOrder(orderDto);
    }

}
