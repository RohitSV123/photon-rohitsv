package com.photon.interview.rohitsv.order_service.exception;

public class InvalidProductError extends RuntimeException {

    public InvalidProductError(String message) {
        super(message);
    }
}
