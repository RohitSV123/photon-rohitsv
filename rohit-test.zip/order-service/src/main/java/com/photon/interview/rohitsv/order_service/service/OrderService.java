package com.photon.interview.rohitsv.order_service.service;

import com.photon.interview.rohitsv.order_service.exception.InvalidProductError;
import com.photon.interview.rohitsv.order_service.repository.OrderRepository;
import com.photon.interview.rohitsv.order_service.model.entity.Order;
import com.photon.interview.rohitsv.order_service.model.dto.OrderDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class  OrderService {

    private final OrderRepository orderRepository;
    private final String productServiceUrl;

    private final RestTemplate restTemplate;

    public OrderService(OrderRepository orderRepository, @Value("${product.service.url}") String productServiceUrl, RestTemplate restTemplate) {
        this.orderRepository = orderRepository;
        this.productServiceUrl = productServiceUrl;
        this.restTemplate = restTemplate;
    }

    public OrderDto createOrder(OrderDto orderDto) throws InvalidProductError {
        long productId = orderDto.getProductId();
        ResponseEntity<Object> productResposne = null;
        try {
            productResposne = restTemplate.getForEntity(productServiceUrl+"?id="+productId, Object.class);
        } catch(RestClientException rce) {
            System.out.println(rce);
        }

        if(productResposne != null && productResposne.getStatusCode() == HttpStatus.OK
                && productResposne.getBody()!=null) {
            Order order = this.transform(orderDto);
            return this.transform(orderRepository.save(order));
        }
        else {
            throw new InvalidProductError("Invalid product selected, please check the request again");
        }
    }

    private Order transform(OrderDto orderDto) {
        return Order.builder()
                         .id(orderDto.getId())
                         .customerName(orderDto.getCustomerName())
                         .productId(orderDto.getProductId())
                         .orderDate(orderDto.getOrderDate())
                         .build();
    }

    private OrderDto transform(Order Order) {
        return OrderDto.builder()
                        .id(Order.getId())
                        .customerName(Order.getCustomerName())
                        .productId(Order.getProductId())
                        .orderDate(Order.getOrderDate())
                        .build();
    }
}
