package com.photon.interview.rohitsv.order_service.exception;

import com.photon.interview.rohitsv.order_service.exception.InvalidProductError;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler implements ErrorController {

    @ExceptionHandler(value = RuntimeException.class)
    public ResponseEntity<String> handleRuntimeException(InvalidProductError ex) {
        return ResponseEntity.internalServerError().body(ex.getMessage());
    }
}
