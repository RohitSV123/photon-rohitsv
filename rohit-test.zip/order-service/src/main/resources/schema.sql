CREATE SCHEMA IF NOT EXISTS test;

CREATE TABLE IF NOT EXISTS test.orders (
     id                   INTEGER PRIMARY KEY,
     customer_name        VARCHAR(20),
     product_id           INTEGER,
     order_date           VARCHAR(20)
);