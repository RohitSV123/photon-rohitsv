insert into test.orders
(id, customer_name, product_id, order_date)
values
(1, 'rohit', '1', '2024-09-01');